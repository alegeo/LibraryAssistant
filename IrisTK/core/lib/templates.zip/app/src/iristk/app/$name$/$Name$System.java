package iristk.app.$name$;

import iristk.system.IrisSystem;
import iristk.flow.FlowModule;

public class $Name$System {

	public $Name$System() throws Exception {
		IrisSystem system = new IrisSystem("$name$");
		system.addModule("flow", new FlowModule(new $Name$Flow()));
		system.start();
	}

	public static void main(String[] args) throws Exception {
		new $Name$System();
	}

}
