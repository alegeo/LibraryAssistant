package iristk.app.$name$;

import iristk.system.Event;
import iristk.flow.*;
import iristk.util.Record;
import static iristk.util.Converters.*;

public class $Name$Flow extends iristk.flow.Flow {


	public Object getVariable(String name) {
		return null;
	}

	public void setVariable(String name, Object value) {
	}

	public $Name$Flow() {
	}

	@Override
	protected State getInitialState() {return new iristk.app.$name$.$Name$Flow.Start();}


	private class Start extends State {



		@Override
		public void setParameters(Record parameters) {
			super.setParameters(parameters);
		}

		@Override
		public boolean onFlowEvent(Event event) {
			if (event instanceof EntryEvent) {
				boolean propagate = false;
				EXECUTION: {
					System.out.println("Hello World!");
					System.exit(0);
				}
				if (!propagate) return true;
			}
			if (super.onFlowEvent(event)) return true;
			if (callerHandlers(event)) return true;
			return false;
		}
		@Override
		public boolean onExit() {
			return super.onExit();
		}

	}


}
