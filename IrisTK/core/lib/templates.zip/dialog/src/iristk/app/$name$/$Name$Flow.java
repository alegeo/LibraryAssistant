package iristk.app.$name$;

import iristk.system.Event;
import iristk.flow.*;
import iristk.util.Record;
import static iristk.util.Converters.*;

public class $Name$Flow extends iristk.flow.Flow {


	public Object getVariable(String name) {
		return null;
	}

	public void setVariable(String name, Object value) {
	}

	public $Name$Flow() {
	}

	@Override
	protected State getInitialState() {return new iristk.app.$name$.$Name$Flow.AskFruit();}


	private class AskFruit extends State {



		@Override
		public void setParameters(Record parameters) {
			super.setParameters(parameters);
		}

		@Override
		public boolean onFlowEvent(Event event) {
			if (event instanceof EntryEvent) {
				boolean propagate = false;
				EXECUTION: {
					Record actionParams0 = new Record();
					actionParams0.put("text", "Please name a fruit");
					if (!iristk.dialog.SimpleDialog.say.execute(flowRunner, actionParams0)) break EXECUTION;
					Record actionParams1 = new Record();
					if (!iristk.dialog.SimpleDialog.listen.execute(flowRunner, actionParams1)) break EXECUTION;
				}
				if (!propagate) return true;
			}
			Record catchParams2 = new Record();
			if (iristk.dialog.SimpleDialog.onNoSpeech.test(event, catchParams2)) {
				boolean propagate = false;
				EXECUTION: {
					Record actionParams3 = new Record();
					actionParams3.put("text", "You didn't say anything");
					if (!iristk.dialog.SimpleDialog.say.execute(flowRunner, actionParams3)) break EXECUTION;
					Record gotoParams4 = new Record();
					flowRunner.gotoState(new AskFruit(), gotoParams4, this);
					break EXECUTION;
				}
				if (!propagate) return true;
			}
			Record catchParams5 = new Record();
			catchParams5.put("sem", "fruit");
			if (iristk.dialog.SimpleDialog.onSpeech.test(event, catchParams5)) {
				boolean propagate = false;
				EXECUTION: {
					Record actionParams6 = new Record();
					actionParams6.put("text", concat("You said ", event.get("sem:fruit")));
					if (!iristk.dialog.SimpleDialog.say.execute(flowRunner, actionParams6)) break EXECUTION;
					Record gotoParams7 = new Record();
					flowRunner.gotoState(new AskFruit(), gotoParams7, this);
					break EXECUTION;
				}
				if (!propagate) return true;
			}
			Record catchParams8 = new Record();
			if (iristk.dialog.SimpleDialog.onSpeech.test(event, catchParams8)) {
				boolean propagate = false;
				EXECUTION: {
					Record actionParams9 = new Record();
					actionParams9.put("text", "I didn't get that");
					if (!iristk.dialog.SimpleDialog.say.execute(flowRunner, actionParams9)) break EXECUTION;
					Record gotoParams10 = new Record();
					flowRunner.gotoState(new AskFruit(), gotoParams10, this);
					break EXECUTION;
				}
				if (!propagate) return true;
			}
			if (super.onFlowEvent(event)) return true;
			if (callerHandlers(event)) return true;
			return false;
		}
		@Override
		public boolean onExit() {
			return super.onExit();
		}

	}


}
