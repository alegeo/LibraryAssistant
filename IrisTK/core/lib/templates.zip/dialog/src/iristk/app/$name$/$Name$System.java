package iristk.app.$name$;

import iristk.app.example.ExampleFlow;
import iristk.audio.PortAudioSource;
import iristk.flow.FlowModule;
import iristk.speech.Recognizer;
import iristk.speech.RecognizerModule;
import iristk.speech.Synthesizer;
import iristk.speech.SynthesizerModule;
import iristk.speech.windows.WindowsRecognizer;
import iristk.speech.windows.WindowsSynthesizer;
import iristk.system.IrisSystem;
import iristk.system.EventLogger;
import iristk.util.Language;
import iristk.util.NameFilter;

public class $Name$System {

	public $Name$System() throws Exception {
		// Initialize the system
		IrisSystem system = new IrisSystem("example");
		// Print all events to the console
		system.addMonitor(new EventLogger(System.out, NameFilter.ALL));

		// Add a flow module to the system
		system.addModule("flow", new FlowModule(new ExampleFlow()));

		// Add a recognizer to the system
		Recognizer asr = new WindowsRecognizer(Language.ENGLISH_US, new PortAudioSource(16000, 1));
		RecognizerModule asrModule = new RecognizerModule(asr);
		system.addModule("asr", asrModule);
		// Load a grammar in the recognizer
		asrModule.loadGrammar("default", getClass().getResource("$Name$Grammar.xml").toURI());
		// Set the default grammar for the recognizer
		asrModule.setDefaultGrammars("default");

		// Add a synthesizer to the system
		Synthesizer tts = new WindowsSynthesizer(Language.ENGLISH_US);
		system.addModule("tts", new SynthesizerModule(tts));

		// Start the system
		system.start();
	}

	public static void main(String[] args) throws Exception {
		new $Name$System();
	}
	
}

