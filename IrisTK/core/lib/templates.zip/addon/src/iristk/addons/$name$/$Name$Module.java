package iristk.addons.$name$;

import iristk.system.*;

public class $Name$Module extends IrisModule {

    public $Name$Module() {
        // Specify which events to subscribe to. You don't need to do this, 
        // but it can improve performance when distributing the system across processes.  
        // subscribe("action.hello");
    }   
	
	@Override
    public void onEvent(Event event) {
        // We have received an event from some other module, 
        // check if we should react to it
        if (event.getName().equals("action.hello")) {
            // Do the hello here together with the parameter "text"
            System.out.println("Hello: " + event.get("text"));
            // Send a monitor event in response
            Event newEvent = new Event("monitor.hello");
            // Add the parameter text, if anyone should be interested
            newEvent.put("text", event.get("text"));
            send(newEvent);
        }
    }

    @Override
    public void init() throws InitializationException {
        // Initialize the module
    }

}
